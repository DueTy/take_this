import { combineReducers } from "redux";
import { agent } from "./agent";

export default combineReducers({ agent });