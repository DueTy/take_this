
import React from "react";

export default class Blank extends React.Component {
    render() {
        return (
            <section className="flex blank-page">
                Page Not Found
            </section>
        );
    }
}